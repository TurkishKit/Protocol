import UIKit

class Animal {
    var name: String!
    var age: Int!
}

class Walk {
    var milesPerHour: Int!
    var sitepSize: Double!
}

class Breath {
    var oxygenPerHour: Int!
    var lungSize: Int!
}

protocol Walkable {
    var milesPerHour: Double { get set }
}

//protocol Breathable {
//    var lungSize: Double { get set }
//}

struct Human: Walkable {
    var milesPerHour: Double
}

struct Cat: Walkable {
    var milesPerHour: Double
}


protocol Flylable {
    func flyNow(speed: Double)
}

struct Bird: Flylable {
    func flyNow(speed: Double) {
        print("Kuş uçuyor.")
    }
}

struct Plane: Flylable {
    func flyNow(speed: Double) {
        print("THY Uçuyor.")
    }
}

let myBird = Bird()
let myPlane = Plane()

myBird.flyNow(speed: 10.0)
myPlane.flyNow(speed: 100.0)

let flaylables: [Flylable] = [myBird, myPlane]


class TableView: UITableView, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        return UITableViewCell()
    }
    
    
}





protocol Drivable {
    var speed: Int { get }
    var numberOfTires: Int { get set }
    func driveNow()
}

extension Drivable {
    var speed: Int {
        return 10
    }
    
    func driveNow() {
    }
}

struct Car: Drivable {
    var speed: Int
    var numberOfTires: Int
}

struct Bus: Drivable {
    var numberOfTires: Int
    var speed: Int
    func driveNow() {
        print("Otobüs Hareket Ediyor.")
    }
}

var myBus = Bus(numberOfTires: 4, speed: 20)
myBus.driveNow()
print("Teker Sayısı: \(myBus.numberOfTires) Hız: \(myBus.speed)")

